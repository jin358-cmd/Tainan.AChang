'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const http = require('node:http');
const path = require('node:path');
const {chromium} = require('playwright');

const root = path.join(__dirname, '..');

function contentType(file) {
  return ({'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.webmanifest':'application/manifest+json','.svg':'image/svg+xml','.png':'image/png'})[path.extname(file)] || 'application/octet-stream';
}

async function startServer(options = {}) {
  const observed = {api:[],external:[],consoleErrors:[],pageErrors:[]};
  const state = {loggedIn:false,role:options.role || 'admin'};
  const server = http.createServer((request, response) => {
    const url = new URL(request.url, 'http://127.0.0.1');
    response.setHeader('Cache-Control', 'no-store');
    if (url.pathname.startsWith('/api/')) {
      const endpoint = url.pathname.slice(5);
      observed.api.push(`${request.method} ${endpoint}`);
      response.setHeader('Content-Type', 'application/json');
      if (endpoint === 'oauth-session' && request.method === 'POST') {
        if (options.oauthFailure) {
          response.statusCode = options.oauthFailure;
          response.end(JSON.stringify({error:'合成帳號尚未授權'}));
        } else {
          state.loggedIn = true;
          response.end(JSON.stringify({ok:true}));
        }
      } else if (endpoint === 'session' && request.method === 'POST') {
        state.loggedIn = true;
        response.end(JSON.stringify({ok:true}));
      } else if (endpoint === 'session' && request.method === 'DELETE') {
        state.loggedIn = false;
        response.end(JSON.stringify({ok:true}));
      } else if (endpoint === 'session' && request.method === 'GET') {
        if (!state.loggedIn) {
          response.statusCode = 401;
          response.end(JSON.stringify({error:'合成工作階段不存在'}));
        } else {
          response.end(JSON.stringify({role:state.role,memberId:state.role === 'volunteer' ? 'synthetic-member' : null,accountId:'synthetic-account',displayName:state.role === 'volunteer' ? '合成志工' : '合成管理員'}));
        }
      } else if (endpoint === 'tasks') response.end(JSON.stringify({tasks:[]}));
      else if (endpoint === 'roster') response.end(JSON.stringify({people:[]}));
      else response.end(JSON.stringify({ok:true}));
      return;
    }
    const relative = url.pathname === '/' ? 'index.html' : decodeURIComponent(url.pathname.slice(1));
    if (relative.includes('..')) { response.statusCode=400; response.end('bad path'); return; }
    if (options.failPublicData && relative === 'data-public.json') {
      response.statusCode = 500;
      response.end('synthetic failure');
      return;
    }
    try {
      response.setHeader('Content-Type', contentType(relative));
      response.end(fs.readFileSync(path.join(root, relative)));
    } catch {
      response.statusCode=404;
      response.end('not found');
    }
  });
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve)});
  return {server,origin:`http://127.0.0.1:${server.address().port}`,observed,state};
}

async function withPage(options, run) {
  const local = await startServer(options);
  const browser = await chromium.launch({headless:true,executablePath:'/usr/bin/chromium'});
  try {
    const context = await browser.newContext({serviceWorkers:'block'});
    await context.route('**/*', route => {
      const url = new URL(route.request().url());
      if (url.origin === local.origin) return route.continue();
      local.observed.external.push(url.href.replace(/[?#].*$/,''));
      return route.abort('blockedbyclient');
    });
    const page = await context.newPage();
    page.on('console', message => { if (message.type()==='error') local.observed.consoleErrors.push(message.text()); });
    page.on('pageerror', error => local.observed.pageErrors.push(error.message));
    await run({page,context,...local});
    await context.close();
    return local.observed;
  } finally {
    await browser.close();
    await new Promise(resolve=>local.server.close(resolve));
  }
}

async function callbackCase(role) {
  return withPage({role}, async ({page,origin,observed}) => {
    const access = 'synthetic_access_' + 'a'.repeat(32);
    const refresh = 'synthetic_refresh_' + 'b'.repeat(24);
    await page.goto(`${origin}/#access_token=${access}&refresh_token=${refresh}&token_type=bearer`, {waitUntil:'domcontentloaded'});
    await page.waitForFunction(() => document.querySelector('#signedInName')?.hidden === false);
    assert.equal(new URL(page.url()).hash, '');
    assert.equal(observed.api.filter(x=>x==='POST oauth-session').length, 1);
    assert.equal(observed.api.filter(x=>x==='GET session').length, 1);
    assert.equal(await page.locator('#secureLogin').getAttribute('hidden') !== null, true);
    assert.equal(await page.locator('#secureLogout').getAttribute('hidden') !== null, false);
    assert.equal(await page.locator('#signedInName').textContent(), role === 'admin' ? '合成管理員' : '合成志工');
    assert.equal(await page.locator('#mapLibre').count(), 1);
    assert.equal(await page.locator('#areaPopup').count(), 1);
    const areasHidden = await page.locator('.bottom-nav [data-page="areas"]').getAttribute('hidden') !== null;
    const plannerHidden = await page.locator('.bottom-nav [data-page="planner"]').getAttribute('hidden') !== null;
    assert.equal(areasHidden, role === 'volunteer');
    assert.equal(plannerHidden, role === 'volunteer');
  });
}

async function oauthFailureCase() {
  return withPage({oauthFailure:403}, async ({page,origin,observed}) => {
    await page.goto(`${origin}/#access_token=synthetic_access&refresh_token=synthetic_refresh`, {waitUntil:'domcontentloaded'});
    await page.waitForFunction(() => !document.querySelector('#secureLogin')?.hidden);
    assert.equal(new URL(page.url()).hash, '');
    assert.equal(observed.api.filter(x=>x==='POST oauth-session').length, 1);
    assert.match(await page.locator('#authStatus').textContent(), /帳號尚未授權或裝置待核准/);
  });
}

async function passwordLogoutReopenCase() {
  return withPage({role:'admin'}, async ({page,origin,observed}) => {
    await page.goto(origin, {waitUntil:'domcontentloaded'});
    await page.waitForFunction(() => document.querySelector('#volunteerLoginBtn')?.hidden === false);
    await page.locator('#volunteerLoginBtn').click();
    await page.waitForFunction(() => !document.querySelector('#secureLogin')?.hidden);
    await page.locator('#secureLoginForm input[name="login"]').fill('synthetic-admin@example.invalid');
    await page.locator('#secureLoginForm input[name="password"]').fill('synthetic-password');
    await page.locator('#secureLoginForm button[type="submit"]').click();
    await page.waitForFunction(() => document.querySelector('#signedInName')?.hidden === false);
    assert.equal(await page.locator('#signedInName').textContent(), '合成管理員');
    await page.locator('#secureLogout').click();
    await page.waitForFunction(() => document.querySelector('#secureLogout')?.hidden === true);
    await page.reload({waitUntil:'domcontentloaded'});
    await page.waitForFunction(() => document.querySelector('#volunteerLoginBtn')?.hidden === false);
    await page.locator('#volunteerLoginBtn').click();
    await page.waitForFunction(() => !document.querySelector('#secureLogin')?.hidden);
    assert.ok(observed.api.includes('POST session'));
    assert.ok(observed.api.includes('DELETE session'));
    assert.ok(observed.api.filter(x=>x==='GET session').length >= 2);
  });
}

async function bootFailureCase() {
  return withPage({failPublicData:true}, async ({page,origin}) => {
    await page.goto(origin, {waitUntil:'domcontentloaded'});
    await page.waitForFunction(() => !document.querySelector('#secureLogin')?.hidden);
    assert.equal(await page.locator('#authStatus').textContent(), '網站暫時無法完成登入，請重新整理後再試');
  });
}

async function mapFallbackCase() {
  return withPage({role:'admin'}, async ({page,origin,observed}) => {
    await page.goto(`${origin}/#access_token=synthetic_access&refresh_token=synthetic_refresh`, {waitUntil:'domcontentloaded'});
    await page.waitForFunction(() => document.querySelector('#signedInName')?.hidden === false);
    await page.locator('.desktop-nav [data-page="map"]').click();
    await page.waitForFunction(() => !document.querySelector('#mapFallback')?.hidden);
    assert.match(await page.locator('#mapFallback').textContent(), /互動地圖/);
    assert.ok(observed.external.some(url=>url.startsWith('https://cdn.jsdelivr.net/npm/maplibre-gl@')));
    assert.equal(observed.external.some(url=>url.includes('supabase.co')), false);
  });
}

(async()=>{
  const results = {
    status:'PASS',
    network:'local synthetic API only; every external request blocked',
    adminCallback:await callbackCase('admin'),
    volunteerCallback:await callbackCase('volunteer'),
    unauthorizedCallback:await oauthFailureCase(),
    passwordLogoutReopen:await passwordLogoutReopenCase(),
    visibleBootFailure:await bootFailureCase(),
    latestUiMapFallback:await mapFallbackCase(),
  };
  const expectedConsoleError = {
    unauthorizedCallback: message => /403 \(Forbidden\)$/.test(message),
    passwordLogoutReopen: message => /401 \(Unauthorized\)$/.test(message),
    visibleBootFailure: message => /500 \(Internal Server Error\)$/.test(message) || /^Error: 地圖資料無法讀取\n/.test(message),
    latestUiMapFallback: message => /net::ERR_(?:FAILED|BLOCKED_BY_CLIENT\.Inspector)$/.test(message),
  };
  for (const [name,result] of Object.entries(results)) {
    if (!result || typeof result !== 'object') continue;
    assert.deepEqual(result.pageErrors, [], `${name} had page errors`);
    const unexpected = result.consoleErrors.filter(message => !/net::ERR_BLOCKED_BY_CLIENT\.Inspector$/.test(message) && !expectedConsoleError[name]?.(message));
    assert.deepEqual(unexpected, [], `${name} had unexpected console errors`);
  }
  process.stdout.write(JSON.stringify(results,null,2)+'\n');
})().catch(error=>{console.error(error.stack||error);process.exitCode=1});
