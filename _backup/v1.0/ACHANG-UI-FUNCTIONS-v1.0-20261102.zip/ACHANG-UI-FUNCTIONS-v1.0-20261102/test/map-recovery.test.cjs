const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const sw = fs.readFileSync(path.join(root, 'sw.js'), 'utf8');
const config = JSON.parse(fs.readFileSync(path.join(root, 'vercel.json'), 'utf8'));
const csp = config.headers[0].headers.find(header => header.key === 'Content-Security-Policy').value;

test('MapLibre worker CSP is narrow and does not relax scripts', () => {
  assert.match(csp, /(?:^|; )worker-src 'self' blob:(?:;|$)/);
  assert.match(csp, /(?:^|; )script-src 'self' https:\/\/cdn\.jsdelivr\.net(?:;|$)/);
  assert.doesNotMatch(csp, /script-src[^;]*blob:/);
  assert.doesNotMatch(csp, /(?:script-src|default-src)[^;]*'unsafe-eval'/);
});

test('map startup has bounded failure, cleanup and retry guards', () => {
  assert.match(app, /MAP_LOAD_TIMEOUT_MS=8000/);
  assert.match(app, /function teardownMap\(\)/);
  assert.match(app, /current\.remove\(\)/);
  assert.match(app, /attempt!==mapAttempt\|\|instance!==map/);
  assert.match(app, /if\(!mapLoaded&&fatalMapStartupError\(message\)\)/);
  assert.match(app, /function mapFailureLabel\(message\)/);
  assert.match(app, /data-retry-map/);
  assert.match(app, /function retryMap\(\)/);
  assert.doesNotMatch(html, /<script[^>]+src="https:\/\/cdn\.jsdelivr\.net\/npm\/maplibre-gl/);
  assert.doesNotMatch(html, /<link[^>]+href="https:\/\/cdn\.jsdelivr\.net\/npm\/maplibre-gl/);
  assert.match(app, /function loadMapStyles\(\)/);
  assert.match(app, /document\.head\.append\(script\)/);
});

test('map asset revision and service-worker cache advance together', () => {
  assert.match(html, /styles\.css\?v=211/);
  assert.match(html, /route-time-filter\.js\?v=2/);
  assert.match(html, /app\.js\?v=222/);
  assert.match(html, /route-directory\.js\?v=3/);
  assert.match(sw, /achang-pwa-shell-v194-auth-safe-weekday-shortcuts/);
});

test('truck directory keeps the route view concise and renders directional route arrows', () => {
  const directory = fs.readFileSync(path.join(__dirname, '..', 'route-directory.js'), 'utf8');
  const directoryCss = fs.readFileSync(path.join(__dirname, '..', 'route-directory.css'), 'utf8');
  assert.match(directory, /class="route-name/);
  assert.match(directory, /class="route-open/);
  assert.match(directory, /class="route-direction"/);
  assert.doesNotMatch(directory, /來源：\$\{esc\(g\.rows\[0\]/);
  assert.match(directoryCss, /#directory th,#directory td,#routeTable th,#routeTable td\{text-align:center\}/);
  assert.match(directoryCss, /\.route-direction\{position:absolute/);
});

test('map uses only the provider native compact attribution entry', () => {
  assert.doesNotMatch(html, /map-source-info|查看地圖與垃圾車資料來源/);
  assert.match(app, /new lib\.AttributionControl\(\{compact:true\}\)/);
  assert.doesNotMatch(app, /customAttribution/);
  assert.doesNotMatch(html, /<p class="map-foot">/);
});

test('volunteer map layer uses the short label and a stable white person icon', () => {
  assert.match(html, /id="layerVolunteer"[^>]*>[\s\S]*?legend-pin volunteer[\s\S]*?legend-person-icon[\s\S]*?<\/span>志工<\/label>/);
  assert.doesNotMatch(html, /<\/span>志工服務<\/label>/);
  const styles = fs.readFileSync(path.join(root, 'styles.css'), 'utf8');
  assert.match(styles, /\.map-switches \.legend-pin \.legend-person-icon\{[^}]*fill:#fff/);
});
